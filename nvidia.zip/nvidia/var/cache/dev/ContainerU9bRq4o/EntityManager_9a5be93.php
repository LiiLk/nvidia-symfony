<?php

namespace ContainerU9bRq4o;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderf134d = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerae37f = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties6dba0 = [
        
    ];

    public function getConnection()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getConnection', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getMetadataFactory', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getExpressionBuilder', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'beginTransaction', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getCache', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getCache();
    }

    public function transactional($func)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'transactional', array('func' => $func), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->transactional($func);
    }

    public function commit()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'commit', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->commit();
    }

    public function rollback()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'rollback', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getClassMetadata', array('className' => $className), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'createQuery', array('dql' => $dql), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'createNamedQuery', array('name' => $name), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'createQueryBuilder', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'flush', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'clear', array('entityName' => $entityName), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->clear($entityName);
    }

    public function close()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'close', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->close();
    }

    public function persist($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'persist', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'remove', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'refresh', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'detach', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'merge', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getRepository', array('entityName' => $entityName), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'contains', array('entity' => $entity), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getEventManager', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getConfiguration', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'isOpen', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getUnitOfWork', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getProxyFactory', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'initializeObject', array('obj' => $obj), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'getFilters', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'isFiltersStateClean', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'hasFilters', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return $this->valueHolderf134d->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerae37f = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderf134d) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderf134d = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderf134d->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__get', ['name' => $name], $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        if (isset(self::$publicProperties6dba0[$name])) {
            return $this->valueHolderf134d->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf134d;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderf134d;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf134d;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderf134d;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__isset', array('name' => $name), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf134d;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderf134d;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__unset', array('name' => $name), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf134d;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderf134d;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__clone', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        $this->valueHolderf134d = clone $this->valueHolderf134d;
    }

    public function __sleep()
    {
        $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, '__sleep', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;

        return array('valueHolderf134d');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerae37f = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerae37f;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerae37f && ($this->initializerae37f->__invoke($valueHolderf134d, $this, 'initializeProxy', array(), $this->initializerae37f) || 1) && $this->valueHolderf134d = $valueHolderf134d;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderf134d;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderf134d;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
